//#ifndef SSAORenderer_h__
//#define SSAORenderer_h__
//
//#include "DXUT.h"
//#include "DXUTcamera.h"
//#include "SDKMesh.h"
//#include <vector>
//
//class SSAORenderer
//{
//public:
//	SSAORenderer(void);
//	~SSAORenderer(void);
//
//	void OnD3D11ResizedSwapChain(ID3D11Device* pd3dDevice, const DXGI_SURFACE_DESC* backBufferDesc);
//
//
//	void RenderScene(ID3D11DeviceContext* pd3dImmediateContext, ID3D11RenderTargetView* pRTV, ID3D11DepthStencilView* pDSV);
//
//private:
//
//	void RenderSSAO();
//
//	void BlurSSAO();
//
//
//
//private:
//
//	ID3D11InputLayout* mVertexLayout;
//
//	ID3D11VertexShader* mVertexShader;
//	ID3D11PixelShader* mPixelShader;
//
//	ID3D11SamplerState* mLinearSampler;
//
//	ID3D11RenderTargetView* mSSAORTV;   
//	ID3D11ShaderResourceView* mSSAOSRV;
//
//	//std:vector<ID3D11Texture2D*> mGBuffer;
//	std::vector<ID3D11RenderTargetView*> mGBufferRTV;
//	std::vector<ID3D11ShaderResourceView*> mGBufferSRV;
//	
//};
//
//#endif // SSAORenderer_h__